package com.example.payment.model;

/**
 * Represents the outcome of a payment attempt.
 */
public record PaymentResult(
    String transactionId,
    boolean success,
    String message,
    String provider
) {}
