package com.example.payment.model;

import java.util.Map;

/**
 * Represents an incoming payment request from the client.
 */
public record PaymentRequest(
    String orderId,
    double amount,
    String currency,
    Map<String, String> metadata   // e.g. cardToken, upiId, walletId
) {}
