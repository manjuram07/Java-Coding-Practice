package com.example.payment.config;

import com.example.payment.context.PaymentContext;
import com.example.payment.service.PaymentService;
import com.example.payment.strategy.PaymentStrategy;
import com.example.payment.strategy.impl.CreditCardStrategy;
import com.example.payment.strategy.impl.UpiStrategy;
import com.example.payment.strategy.impl.WalletStrategy;

import java.util.List;

/**
 * Wires all payment beans together.
 *
 * In a Spring Boot project, annotate this class with @Configuration
 * and each method with @Bean — Spring will inject List<PaymentStrategy>
 * automatically into PaymentContext.
 *
 * Non-Spring: use this class as a manual factory / DI root.
 */
public class PaymentConfig {

    public List<PaymentStrategy> paymentStrategies() {
        return List.of(
            new CreditCardStrategy(),
            new UpiStrategy(),
            new WalletStrategy()
            // Add new providers here — no other file changes needed
        );
    }

    public PaymentContext paymentContext() {
        return new PaymentContext(paymentStrategies());
    }

    public PaymentService paymentService() {
        return new PaymentService(paymentContext());
    }
}
