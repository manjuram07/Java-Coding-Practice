package com.example.payment.strategy.impl;

import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;
import com.example.payment.strategy.PaymentStrategy;

import java.util.UUID;

/**
 * Handles CREDIT_CARD and DEBIT_CARD payments.
 * In production: integrate Stripe / Razorpay SDK here.
 */
public class CreditCardStrategy implements PaymentStrategy {

    @Override
    public PaymentResult pay(PaymentRequest request) {
        String cardToken = request.metadata().get("cardToken");

        System.out.printf("[CreditCard] Charging ₹%.2f using token: %s%n",
                request.amount(), cardToken);

        if (cardToken == null || cardToken.isBlank()) {
            return new PaymentResult(null, false, "Card token is missing", "CreditCard");
        }

        // TODO: call Stripe/Razorpay gateway here
        String txnId = "CC-" + UUID.randomUUID();
        return new PaymentResult(txnId, true, "Payment successful", "CreditCard");
    }

    @Override
    public boolean supports(String paymentMethod) {
        return "CREDIT_CARD".equalsIgnoreCase(paymentMethod)
            || "DEBIT_CARD".equalsIgnoreCase(paymentMethod);
    }
}
