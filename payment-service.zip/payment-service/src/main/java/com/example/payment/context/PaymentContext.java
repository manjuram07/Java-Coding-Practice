package com.example.payment.context;

import com.example.payment.exception.UnsupportedPaymentMethodException;
import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;
import com.example.payment.strategy.PaymentStrategy;

import java.util.List;

/**
 * Selects and delegates to the correct PaymentStrategy at runtime.
 *
 * Spring usage: inject List<PaymentStrategy> and Spring auto-collects
 * all beans implementing the interface.
 *
 *   @Autowired
 *   public PaymentContext(List<PaymentStrategy> strategies) { ... }
 */
public class PaymentContext {

    private final List<PaymentStrategy> strategies;

    public PaymentContext(List<PaymentStrategy> strategies) {
        this.strategies = strategies;
    }

    public PaymentResult process(String paymentMethod, PaymentRequest request) {
        return strategies.stream()
            .filter(s -> s.supports(paymentMethod))
            .findFirst()
            .orElseThrow(() -> new UnsupportedPaymentMethodException(paymentMethod))
            .pay(request);
    }
}
