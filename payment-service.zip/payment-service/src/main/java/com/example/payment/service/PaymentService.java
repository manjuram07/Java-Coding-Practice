package com.example.payment.service;

import com.example.payment.context.PaymentContext;
import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;

/**
 * Business-layer service.
 * Orchestrates payment processing — add logging, auditing,
 * idempotency checks, and event publishing here.
 */
public class PaymentService {

    private final PaymentContext paymentContext;

    public PaymentService(PaymentContext paymentContext) {
        this.paymentContext = paymentContext;
    }

    /**
     * Process a payment using the appropriate strategy.
     *
     * @param paymentMethod  e.g. "CREDIT_CARD", "UPI", "WALLET"
     * @param request        payment details
     * @return               result with txn ID and status
     */
    public PaymentResult processPayment(String paymentMethod, PaymentRequest request) {
        // TODO: idempotency check (look up request.orderId() in DB)
        // TODO: pre-payment audit log

        PaymentResult result = paymentContext.process(paymentMethod, request);

        // TODO: persist result to PaymentTransaction table
        // TODO: publish PaymentSucceeded / PaymentFailed domain event

        return result;
    }
}
