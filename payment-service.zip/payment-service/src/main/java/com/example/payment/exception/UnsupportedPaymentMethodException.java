package com.example.payment.exception;

/**
 * Thrown when no registered strategy supports the requested payment method.
 */
public class UnsupportedPaymentMethodException extends RuntimeException {

    public UnsupportedPaymentMethodException(String paymentMethod) {
        super("No payment strategy found for method: " + paymentMethod);
    }
}
