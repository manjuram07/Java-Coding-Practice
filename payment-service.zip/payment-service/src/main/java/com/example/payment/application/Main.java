package com.example.payment.application;

import com.example.payment.config.PaymentConfig;
import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;
import com.example.payment.service.PaymentService;

import java.util.Map;

/**
 * Entry point — demonstrates all payment flows.
 * In Spring Boot, replace this with a @RestController.
 */
public class Main {

    public static void main(String[] args) {
        PaymentConfig config   = new PaymentConfig();
        PaymentService service = config.paymentService();

        // ── Credit Card ──────────────────────────────
        run(service, "CREDIT_CARD", new PaymentRequest(
            "ORDER-101", 1499.00, "INR",
            Map.of("cardToken", "tok_visa_4242")
        ));

        // ── UPI ──────────────────────────────────────
        run(service, "UPI", new PaymentRequest(
            "ORDER-102", 299.00, "INR",
            Map.of("upiId", "user@okaxis")
        ));

        // ── Wallet (success) ─────────────────────────
        run(service, "WALLET", new PaymentRequest(
            "ORDER-103", 199.00, "INR",
            Map.of("walletId", "wallet_001")
        ));

        // ── Wallet (insufficient balance) ────────────
        run(service, "WALLET", new PaymentRequest(
            "ORDER-104", 9999.00, "INR",
            Map.of("walletId", "wallet_002")
        ));

        // ── Unsupported method ───────────────────────
        try {
            run(service, "CRYPTO", new PaymentRequest(
                "ORDER-105", 500.00, "INR",
                Map.of()
            ));
        } catch (Exception e) {
            System.out.println("[ERROR] " + e.getMessage());
        }
    }

    private static void run(PaymentService service, String method, PaymentRequest req) {
        System.out.println("──────────────────────────────────────");
        PaymentResult result = service.processPayment(method, req);
        System.out.println("Result : " + result);
        System.out.println();
    }
}
