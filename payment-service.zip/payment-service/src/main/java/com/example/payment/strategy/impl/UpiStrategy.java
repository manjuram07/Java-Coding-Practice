package com.example.payment.strategy.impl;

import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;
import com.example.payment.strategy.PaymentStrategy;

import java.util.UUID;

/**
 * Handles UPI payments (NPCI / VPA based).
 * In production: integrate payment gateway UPI API here.
 */
public class UpiStrategy implements PaymentStrategy {

    @Override
    public PaymentResult pay(PaymentRequest request) {
        String upiId = request.metadata().get("upiId");

        System.out.printf("[UPI] Sending ₹%.2f to UPI ID: %s%n",
                request.amount(), upiId);

        if (upiId == null || !upiId.contains("@")) {
            return new PaymentResult(null, false, "Invalid UPI ID format", "UPI");
        }

        // TODO: call UPI gateway API here
        String txnId = "UPI-" + UUID.randomUUID();
        return new PaymentResult(txnId, true, "UPI payment successful", "UPI");
    }

    @Override
    public boolean supports(String paymentMethod) {
        return "UPI".equalsIgnoreCase(paymentMethod);
    }
}
