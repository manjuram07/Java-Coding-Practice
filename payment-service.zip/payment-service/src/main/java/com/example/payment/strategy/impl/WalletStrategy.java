package com.example.payment.strategy.impl;

import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;
import com.example.payment.strategy.PaymentStrategy;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Handles in-app Wallet payments.
 * In production: replace walletBalances with a DB-backed WalletRepository.
 */
public class WalletStrategy implements PaymentStrategy {

    // Simulated wallet store — replace with WalletRepository in production
    private final Map<String, Double> walletBalances = new HashMap<>(Map.of(
        "wallet_001", 2000.0,
        "wallet_002", 500.0
    ));

    @Override
    public PaymentResult pay(PaymentRequest request) {
        String walletId = request.metadata().get("walletId");
        double balance  = walletBalances.getOrDefault(walletId, 0.0);

        System.out.printf("[Wallet] Deducting ₹%.2f from wallet: %s (balance: ₹%.2f)%n",
                request.amount(), walletId, balance);

        if (balance < request.amount()) {
            return new PaymentResult(null, false, "Insufficient wallet balance", "Wallet");
        }

        walletBalances.put(walletId, balance - request.amount());
        String txnId = "WAL-" + UUID.randomUUID();
        return new PaymentResult(txnId, true, "Wallet payment successful", "Wallet");
    }

    @Override
    public boolean supports(String paymentMethod) {
        return "WALLET".equalsIgnoreCase(paymentMethod);
    }
}
