package com.example.payment.strategy;

import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResult;

/**
 * Strategy interface — every payment provider must implement this.
 * Adding a new provider = adding a new class, zero changes to existing code.
 */
public interface PaymentStrategy {

    /**
     * Execute the payment using this provider's logic.
     */
    PaymentResult pay(PaymentRequest request);

    /**
     * Returns true if this strategy can handle the given payment method.
     * e.g. "CREDIT_CARD", "UPI", "WALLET"
     */
    boolean supports(String paymentMethod);
}
